declare const styles: {
  readonly "output": string;
};
export = styles;

