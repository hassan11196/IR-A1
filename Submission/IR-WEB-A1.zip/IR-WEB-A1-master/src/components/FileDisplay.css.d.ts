declare const styles: {
  readonly "scrollable": string;
};
export = styles;

