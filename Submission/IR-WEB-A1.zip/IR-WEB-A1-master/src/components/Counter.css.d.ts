declare const styles: {
  readonly "backButton": string;
  readonly "counter": string;
  readonly "btnGroup": string;
  readonly "btn": string;
};
export = styles;

