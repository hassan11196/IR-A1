declare const styles: {
  readonly "container": string;
  readonly "h1": string;
};
export = styles;

