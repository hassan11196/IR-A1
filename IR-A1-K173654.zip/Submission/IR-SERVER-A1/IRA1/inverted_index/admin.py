from django.contrib import admin
from .models import InvertedIndexModel
# Register your models here.
admin.site.register(InvertedIndexModel)