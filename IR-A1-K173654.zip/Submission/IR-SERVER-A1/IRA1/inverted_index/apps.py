from django.apps import AppConfig


class InvertedIndexConfig(AppConfig):
    name = 'inverted_index'
